it('Google Search',() => {
    cy.visit('http://localhost/Online-Food-Ordering-System-in-PHP-main/')
    cy.get(':nth-child(4) > .nav-link').click()
    cy.get(':nth-child(1) > #example-text-input').type('admin')
    cy.get(':nth-child(2) > #example-text-input').type('Sasi')
    cy.get('#example-text-input-2').type('Rashmika')
    cy.get('#exampleInputEmail1').type('sasirashmika25@gmail.com')
    cy.get('#example-tel-input-3').type('0754700309')
    cy.get('#exampleInputPassword1').type('Watch Youtube Video')
    cy.get('#exampleInputPassword2').type('Watch Youtube Video')
    cy.get('#exampleTextarea').type('Ballapana,Gligamuwa,town')
    cy.get('.btn').click()

})